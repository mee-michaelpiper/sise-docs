using Microsoft.AspNetCore.Components;
using MudBlazor;
using System.Security.Claims;
using Meesenburg.ES.Web.Theme;

namespace Meesenburg.ES.Web.Components.Layout
{
    public partial class MainLayout
    {
        [Inject] protected NavigationManager NavigationManager { get; set; } = default!;
        [Inject] protected IHttpContextAccessor HttpContextAccessor { get; set; } = default!;

        private readonly MudTheme _theme = MeesenburgTheme.Theme;
        private MudThemeProvider _themeProvider = default!;

        private bool _drawerOpen = true;
        private bool _isDarkMode;
        private bool _darkModeInitialized;

        private string logoutRedirectUri = string.Empty;

        private void ToggleDrawer() => _drawerOpen = !_drawerOpen;

        private void ToggleDarkMode() => _isDarkMode = !_isDarkMode;

        protected override void OnInitialized()
        {
            var request = HttpContextAccessor.HttpContext?.Request;
            if (request is null)
                return;

            var loginHint = request.HttpContext.User.FindFirstValue("login_hint");

            logoutRedirectUri = "https://login.microsoftonline.com/common/oauth2/v2.0/logout?post_logout_redirect_uri="
                                + Uri.EscapeDataString(request.Scheme + Uri.SchemeDelimiter + request.Host + request.PathBase + "/signout-oidc");

            if (loginHint != null)
            {
                logoutRedirectUri += "&logout_hint=" + Uri.EscapeDataString(loginHint);
            }
        }

        protected override async Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender && !_darkModeInitialized)
            {
                // Beim ersten Laden Systemeinstellung des Nutzers übernehmen.
                _darkModeInitialized = true;
                _isDarkMode = await _themeProvider.GetSystemDarkModeAsync();
                StateHasChanged();
            }
        }
    }
}
