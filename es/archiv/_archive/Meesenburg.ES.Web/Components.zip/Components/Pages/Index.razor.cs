using Microsoft.AspNetCore.Components;

namespace Meesenburg.ES.Web.Components.Pages;

public partial class Index
{
    [Inject]
    protected NavigationManager NavigationManager { get; set; } = default!;

    private void Login()
    {
        var returnUrl = new Uri(NavigationManager.Uri).PathAndQuery;
        var url = $"/login?returnUrl={Uri.EscapeDataString(returnUrl)}";
        NavigationManager.NavigateTo(url, forceLoad: true);
    }

    private void Logout()
    {
        NavigationManager.NavigateTo("/logout", forceLoad: true);
    }
}
